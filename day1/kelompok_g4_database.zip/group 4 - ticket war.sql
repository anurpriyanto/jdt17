-- DDL: CREATE TABLES

CREATE TABLE users (
    id         VARCHAR(255) PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    role       VARCHAR(20)  NOT NULL DEFAULT 'USER'
        CHECK (role IN ('ADMIN', 'USER')),
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE seats (
    id                VARCHAR(255) PRIMARY KEY,
    name              VARCHAR(50)    NOT NULL UNIQUE,
    price             DECIMAL(12, 2) NOT NULL,
    quota_total       INT            NOT NULL,
    quota_available   INT            NOT NULL,
    quota_suspended   INT            NOT NULL DEFAULT 0,
    created_at        TIMESTAMP      NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_quota_available   CHECK (quota_available >= 0),
    CONSTRAINT chk_quota_suspended   CHECK (quota_suspended >= 0),
    CONSTRAINT chk_quota_total       CHECK (quota_total > 0)
);

CREATE TABLE payment_methods (
    id         VARCHAR(255) PRIMARY KEY,
    name       VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP   NOT NULL DEFAULT NOW()
);

CREATE TABLE transactions (
    id                VARCHAR(255) PRIMARY KEY,
    user_id           VARCHAR(255)   NOT NULL REFERENCES users(id),
    seat_id           VARCHAR(255)   NOT NULL REFERENCES seats(id),
    payment_method_id VARCHAR(255)   NOT NULL REFERENCES payment_methods(id),
    status            VARCHAR(20)    NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'PAID', 'FAILED', 'REFUNDED')),
    paid_at           TIMESTAMP,
    refunded_at       TIMESTAMP,
    created_at        TIMESTAMP      NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMP      NOT NULL DEFAULT NOW()
);

-- DML: SEED DATA

INSERT INTO users (id ,name, email, role) VALUES
    ('ADMIN-1','Admin Konser',   'admin@concert.com',   'ADMIN'),
    ('USER-1','Budi Santoso',   'budi@gmail.com',      'USER'),
    ('USER-2', 'Sari Dewi',      'sari@gmail.com',      'USER'),
    ('USER-3' ,'Andi Pratama',   'andi@gmail.com',      'USER');

INSERT INTO seats (id, name, price, quota_total, quota_available) VALUES
    ('SEAT-1', 'Festival', 350000,  80000, 80000),
    ('SEAT-2','VIP1',     750000,  50000, 50000),
    ('SEAT-3','VIP2',     1250000, 50000, 50000),
    ('SEAT-4','VIP3',     2000000, 50000, 50000);

INSERT INTO payment_methods (id, name) VALUES
    ('PM-1','Bank Transfer'),
    ('PM-2', 'E-Wallet'),
    ('PM-3','Credit Card'),
    ('PM-4','Virtual Account');

-- SIMULASI ALUR TRANSAKSI

-- Buat transaksi baru (PENDING)
BEGIN;

INSERT INTO transactions (id, user_id, seat_id, payment_method_id, status)
VALUES ('TR-190526-FST-1','USER-2', 'SEAT-1', 'PM-2', 'PENDING'); -- Budi beli Festival via E-Wallet

SELECT * FROM transactions;

COMMIT;


-- Pembayaran berhasil (PENDING → PAID) -> kuota berkurang
BEGIN;

UPDATE transactions
SET status = 'PAID', paid_at = NOW(), updated_at = NOW()
WHERE id = 'TR-190526-FST-1' AND status = 'PENDING';

SELECT * FROM transactions;

UPDATE seats
SET quota_available = quota_available - 1
WHERE id = 'SEAT-1' AND quota_available > 0;

SELECT * FROM seats;

COMMIT;


-- Pembayaran gagal (PENDING → FAILED)
BEGIN;
-- Buat transaksi baru dulu untuk simulasi gagal
INSERT INTO transactions (id, user_id, seat_id, payment_method_id, status)
VALUES ('TR-190526-VIP1-2', 'USER-3', 'SEAT-2', 'PM-1', 'PENDING'); -- Sari beli VIP1 via Bank Transfer

SELECT * FROM transactions;

-- Simulasi gagal bayar
UPDATE transactions
SET status = 'FAILED', updated_at = NOW()
WHERE id = 'TR-190526-VIP1-2' AND status = 'PENDING';

SELECT * FROM transactions;

COMMIT;

-- Refund (PAID → REFUNDED) → masuk quota_suspended
BEGIN;

UPDATE transactions
SET status = 'REFUNDED', refunded_at = NOW(), updated_at = NOW()
WHERE id = 'TR-190526-FST-1' AND status = 'PAID';

SELECT * FROM transactions;

UPDATE seats
SET quota_suspended = quota_suspended + 1
WHERE id = 'SEAT-1';

SELECT * FROM seats;

COMMIT;

-- REPORT VIEW

INSERT INTO transactions (id, user_id, seat_id, payment_method_id, status, paid_at, refunded_at, created_at, updated_at) VALUES
                                                                                                                             -- Festival
     ('TR-190526-FST-100', 'USER-1', 'SEAT-1', 'PM-2', 'PAID',     NOW() - INTERVAL '5 hours', NULL,                       NOW() - INTERVAL '6 hours', NOW() - INTERVAL '5 hours'),
     ('TR-190526-FST-101', 'USER-2', 'SEAT-1', 'PM-1', 'PAID',     NOW() - INTERVAL '4 hours', NULL,                       NOW() - INTERVAL '5 hours', NOW() - INTERVAL '4 hours'),
     ('TR-190526-FST-102', 'USER-3', 'SEAT-1', 'PM-3', 'REFUNDED', NOW() - INTERVAL '3 hours', NOW() - INTERVAL '1 hour',  NOW() - INTERVAL '4 hours', NOW() - INTERVAL '1 hour'),
     ('TR-190526-FST-103', 'USER-1', 'SEAT-1', 'PM-4', 'FAILED',   NULL,                       NULL,                       NOW() - INTERVAL '3 hours', NOW() - INTERVAL '3 hours'),
     ('TR-190526-FST-104', 'USER-2', 'SEAT-1', 'PM-2', 'PENDING',  NULL,                       NULL,                       NOW() - INTERVAL '1 hour',  NOW() - INTERVAL '1 hour'),

     -- VIP1
     ('TR-190526-VIP1-100', 'USER-1', 'SEAT-2', 'PM-3', 'PAID',     NOW() - INTERVAL '5 hours', NULL,                      NOW() - INTERVAL '6 hours', NOW() - INTERVAL '5 hours'),
     ('TR-190526-VIP1-101', 'USER-3', 'SEAT-2', 'PM-2', 'PAID',     NOW() - INTERVAL '4 hours', NULL,                      NOW() - INTERVAL '5 hours', NOW() - INTERVAL '4 hours'),
     ('TR-190526-VIP1-102', 'USER-2', 'SEAT-2', 'PM-1', 'FAILED',   NULL,                       NULL,                      NOW() - INTERVAL '3 hours', NOW() - INTERVAL '3 hours'),
     ('TR-190526-VIP1-103', 'USER-1', 'SEAT-2', 'PM-4', 'REFUNDED', NOW() - INTERVAL '2 hours', NOW() - INTERVAL '30 minutes', NOW() - INTERVAL '3 hours', NOW() - INTERVAL '30 minutes'),

     -- VIP2
     ('TR-190526-VIP2-100', 'USER-2', 'SEAT-3', 'PM-1', 'PAID',    NOW() - INTERVAL '5 hours', NULL, NOW() - INTERVAL '6 hours', NOW() - INTERVAL '5 hours'),
     ('TR-190526-VIP2-101', 'USER-3', 'SEAT-3', 'PM-3', 'PAID',    NOW() - INTERVAL '3 hours', NULL, NOW() - INTERVAL '4 hours', NOW() - INTERVAL '3 hours'),
     ('TR-190526-VIP2-102', 'USER-1', 'SEAT-3', 'PM-2', 'PENDING', NULL,                       NULL, NOW() - INTERVAL '30 minutes', NOW() - INTERVAL '30 minutes'),

     -- VIP3
     ('TR-190526-VIP3-100', 'USER-3', 'SEAT-4', 'PM-4', 'PAID',   NOW() - INTERVAL '5 hours', NULL, NOW() - INTERVAL '6 hours', NOW() - INTERVAL '5 hours'),
     ('TR-190526-VIP3-101', 'USER-1', 'SEAT-4', 'PM-3', 'PAID',   NOW() - INTERVAL '4 hours', NULL, NOW() - INTERVAL '5 hours', NOW() - INTERVAL '4 hours'),
     ('TR-190526-VIP3-102', 'USER-2', 'SEAT-4', 'PM-1', 'FAILED', NULL,                       NULL, NOW() - INTERVAL '2 hours', NOW() - INTERVAL '2 hours');

-- Update kuota seats berdasarkan transaksi di atas
-- Festival : PAID(2) + PENDING(1) + REFUNDED(1) = -3 available, +1 suspended
UPDATE seats SET quota_available = quota_available - 3, quota_suspended = quota_suspended + 1 WHERE id = 'SEAT-1';

-- VIP1     : PAID(2) + REFUNDED(1) = -2 available, +1 suspended
UPDATE seats SET quota_available = quota_available - 2, quota_suspended = quota_suspended + 1 WHERE id = 'SEAT-2';

-- VIP2     : PAID(2) + PENDING(1) = -3 available
UPDATE seats SET quota_available = quota_available - 3 WHERE id = 'SEAT-3';

-- VIP3     : PAID(2) = -2 available
UPDATE seats SET quota_available = quota_available - 2 WHERE id = 'SEAT-4';


-- REPORT 1: Ringkasan kuota per seat
SELECT
    s.name AS seat,
    s.price,
    s.quota_total,
    s.quota_available,
    s.quota_suspended,
    (s.quota_total - s.quota_available - s.quota_suspended) AS quota_sold
FROM seats s
ORDER BY s.id;

-- REPORT 2: Ringkasan transaksi per status
SELECT
    s.name        AS seat,
    t.status,
    pm.name       AS payment_method,
    u.name        AS user_name,
    t.paid_at,
    t.refunded_at,
    t.created_at
FROM transactions t
         JOIN users u  ON t.user_id = u.id
         JOIN seats s  ON t.seat_id = s.id
         JOIN payment_methods pm ON t.payment_method_id = pm.id
ORDER BY t.created_at DESC;

-- REPORT 3: Total kerugian dari refund per seat

SELECT
    s.name                  AS seat,
    s.price,
    COUNT(t.id)             AS total_tiket_refund,
    SUM(s.price)            AS total_kerugian
FROM transactions t
         JOIN seats s ON t.seat_id = s.id
WHERE t.status = 'REFUNDED'
GROUP BY s.name, s.price
ORDER BY total_kerugian DESC;